require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { Pool } = require('pg');
const path = require('path');

const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '20kb' }));
app.use(express.static(path.join(__dirname, 'public')));
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: true } : false });
const jwtSecret = process.env.JWT_SECRET;
if (!jwtSecret || jwtSecret.length < 32) console.warn('AVISO: configure JWT_SECRET com pelo menos 32 caracteres.');

async function initDb() {
  await pool.query(`CREATE TABLE IF NOT EXISTS licenses (
    id BIGSERIAL PRIMARY KEY, key_hash TEXT NOT NULL UNIQUE, key_hint TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), expires_at TIMESTAMPTZ,
    duration_days INTEGER, status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','blocked','revoked')),
    first_used_at TIMESTAMPTZ, last_validated_at TIMESTAMPTZ
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS audit_log (
    id BIGSERIAL PRIMARY KEY, action TEXT NOT NULL, license_id BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), details JSONB NOT NULL DEFAULT '{}'::jsonb
  )`);
}
const hashKey = key => crypto.createHash('sha256').update(key).digest('hex');
const auth = (req, res, next) => {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  try { req.admin = jwt.verify(token, jwtSecret); next(); }
  catch { res.status(401).json({ error: 'Autenticação necessária.' }); }
};
const adminConfigured = () => process.env.ADMIN_USER && process.env.ADMIN_PASSWORD;

app.get('/api/health', async (_req, res) => {
  try { await pool.query('SELECT 1'); res.json({ ok: true, service: 'SXZ API' }); }
  catch { res.status(503).json({ ok: false, error: 'Banco indisponível' }); }
});
app.post('/api/auth/login', async (req, res) => {
  if (!adminConfigured()) return res.status(503).json({ error: 'Configure ADMIN_USER e ADMIN_PASSWORD no servidor.' });
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || typeof password !== 'string' || username.length > 100 || password.length > 200) return res.status(400).json({ error: 'Dados inválidos.' });
  // Compare hash derivado para reduzir exposição direta do segredo em comparações.
  const expected = crypto.createHash('sha256').update(String(process.env.ADMIN_PASSWORD)).digest();
  const actual = crypto.createHash('sha256').update(password).digest();
  if (username !== process.env.ADMIN_USER || !crypto.timingSafeEqual(expected, actual)) return res.status(401).json({ error: 'Usuário ou senha incorretos.' });
  res.json({ token: jwt.sign({ sub: username, role: 'admin' }, jwtSecret, { expiresIn: '4h' }) });
});
app.post('/api/keys/validate', async (req, res) => {
  const key = String(req.body?.key || '').trim();
  if (key.length < 12 || key.length > 100) return res.status(400).json({ valid: false, status: 'invalid', message: 'KEY inválida.' });
  try {
    const result = await pool.query('SELECT * FROM licenses WHERE key_hash=$1', [hashKey(key)]);
    if (!result.rowCount) return res.status(401).json({ valid: false, status: 'invalid', message: 'KEY inválida.' });
    const lic = result.rows[0];
    if (lic.status !== 'active') return res.status(403).json({ valid: false, status: lic.status, message: lic.status === 'blocked' ? 'KEY bloqueada.' : 'KEY revogada.' });
    if (lic.expires_at && new Date(lic.expires_at).getTime() <= Date.now()) return res.status(403).json({ valid: false, status: 'expired', message: 'KEY expirada.' });
    await pool.query('UPDATE licenses SET first_used_at=COALESCE(first_used_at,NOW()), last_validated_at=NOW() WHERE id=$1', [lic.id]);
    res.json({ valid: true, status: 'active', expiresAt: lic.expires_at, remainingSeconds: lic.expires_at ? Math.max(0, Math.floor((new Date(lic.expires_at).getTime()-Date.now())/1000)) : null, message: 'Licença válida.' });
  } catch { res.status(500).json({ valid: false, status: 'error', message: 'Não foi possível validar. Tente novamente.' }); }
});
app.post('/api/keys', auth, async (req, res) => {
  const days = req.body?.days;
  if (!(days === null || (Number.isInteger(days) && days > 0 && days <= 36500))) return res.status(400).json({ error: 'Informe dias positivos ou null para permanente.' });
  const key = 'SXZ-' + crypto.randomBytes(18).toString('hex').toUpperCase();
  try {
    const r = await pool.query("INSERT INTO licenses(key_hash,key_hint,expires_at,duration_days) VALUES($1,$2,CASE WHEN $3::integer IS NULL THEN NULL ELSE NOW() + ($3::integer * INTERVAL '1 day') END,$3) RETURNING id,created_at,expires_at,duration_days,status", [hashKey(key), key.slice(-6), days]);
    await pool.query('INSERT INTO audit_log(action,license_id,details) VALUES($1,$2,$3)', ['create', r.rows[0].id, JSON.stringify({days})]);
    res.status(201).json({ ...r.rows[0], key });
  } catch { res.status(500).json({ error: 'Não foi possível criar a KEY.' }); }
});
app.get('/api/keys', auth, async (req, res) => {
  try {
    const q = String(req.query.q || '').slice(0, 80);
    const r = await pool.query(`SELECT id,key_hint,created_at,expires_at,duration_days,status,first_used_at,last_validated_at FROM licenses WHERE key_hint ILIKE $1 ORDER BY created_at DESC LIMIT 200`, [`%${q.slice(-6)}%`]);
    res.json({ keys: r.rows });
  } catch { res.status(500).json({ error: 'Falha ao listar licenças.' }); }
});
app.patch('/api/keys/:id/status', auth, async (req, res) => {
  const status = req.body?.status;
  if (!['active','blocked','revoked'].includes(status)) return res.status(400).json({ error: 'Status inválido.' });
  try {
    const r = await pool.query('UPDATE licenses SET status=$1 WHERE id=$2 RETURNING id,status', [status, req.params.id]);
    if (!r.rowCount) return res.status(404).json({ error: 'KEY não encontrada.' });
    await pool.query('INSERT INTO audit_log(action,license_id,details) VALUES($1,$2,$3)', [status, req.params.id, JSON.stringify({admin:req.admin.sub})]);
    res.json(r.rows[0]);
  } catch { res.status(500).json({ error: 'Falha ao atualizar KEY.' }); }
});
app.get('/api/audit', auth, async (_req, res) => {
  try { const r = await pool.query('SELECT id,action,license_id,created_at,details FROM audit_log ORDER BY created_at DESC LIMIT 100'); res.json({ events: r.rows }); }
  catch { res.status(500).json({ error: 'Falha ao consultar auditoria.' }); }
});
const port = Number(process.env.PORT || 3000);
initDb().then(() => app.listen(port, () => console.log(`SXZ API pronta na porta ${port}`))).catch(err => { console.error('Falha ao iniciar banco:', err.message); process.exit(1); });
