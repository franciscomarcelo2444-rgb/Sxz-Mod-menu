# SXZ Mod Menu — projeto inicial

Este pacote contém o código-fonte de um app Android nativo, backend Node.js/Express e painel administrativo web.

## Importante
- O APK ainda precisa ser compilado no Android Studio, pois este ambiente não possui Android SDK/Gradle instalado.
- O backend precisa ser publicado em um servidor HTTPS e conectado a um PostgreSQL antes de distribuir o app.
- O app contém um círculo visual ajustável e menu flutuante; não implementa mira automática nem interação com outros jogos.

## Estrutura
- `android/`: projeto Android Kotlin.
- `backend/`: API REST e painel web de administração.

## Backend
1. Instale Node.js 20+ e PostgreSQL.
2. Crie um banco de dados, por exemplo `sxz`.
3. Copie `backend/.env.example` para `backend/.env` e preencha `DATABASE_URL`, `ADMIN_USER` e `ADMIN_PASSWORD`.
4. No terminal, entre em `backend` e execute `npm install` e `npm start`.
5. Abra `/admin.html` no endereço do servidor.
6. Em produção, coloque a API atrás de HTTPS. Não exponha a API em HTTP público.

## Android
1. Abra a pasta `android` no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Em `android/app/src/main/java/com/sxz/modmenu/MainActivity.kt`, substitua `API_BASE_URL` pelo endereço HTTPS da API.
4. Compile em Build > Build APK(s).
5. Para usar o menu sobre outros apps, permita “Exibir sobre outros apps” nas configurações do Android.

## Licenças
A expiração é calculada pelo servidor no momento da criação da KEY. A chave expirada ou bloqueada é rejeitada pela API. O painel administrativo é uma base inicial e deve ser revisado/testado antes de uso comercial.
