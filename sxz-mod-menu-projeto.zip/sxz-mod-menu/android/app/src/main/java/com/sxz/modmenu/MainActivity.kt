package com.sxz.modmenu

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    companion object { const val API_BASE_URL = "https://YOUR-API-DOMAIN.example.com" }
    private val io = Executors.newSingleThreadExecutor()
    private val red = Color.rgb(255,35,63); private val bg = Color.rgb(8,9,13); private val panel = Color.rgb(21,23,30)
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showLogin() }
    private fun baseColumn(): LinearLayout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,32,24,24); gravity=Gravity.CENTER_HORIZONTAL; setBackgroundColor(bg) }
    private fun text(value:String,size:Float,color:Int=Color.WHITE,bold:Boolean=false)=TextView(this).apply { text=value; textSize=size; setTextColor(color); if(bold) setTypeface(null,android.graphics.Typeface.BOLD); gravity=Gravity.CENTER; setPadding(6,10,6,10) }
    private fun button(value:String, action:()->Unit)=Button(this).apply { text=value; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(red)); setOnClickListener { action() } }
    private fun showLogin(){
        val root=baseColumn(); root.addView(text("◉ SXZ",34f,red,true)); root.addView(text("MOD MENU",21f,Color.WHITE,true)); root.addView(text("Insira sua KEY de acesso",14f,0xFFB7B9C4.toInt()))
        val key=EditText(this).apply { hint="SXZ-..."; setHintTextColor(0xFF777985.toInt()); setTextColor(Color.WHITE); setSingleLine(true); setPadding(16,14,16,14); setBackgroundColor(panel) }
        root.addView(key,LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin=18 }); val agree=CheckBox(this).apply { text="Confirmo que tenho uma licença válida"; setTextColor(Color.LTGRAY); buttonTintList=android.content.res.ColorStateList.valueOf(red) }; root.addView(agree)
        val status=text("A validade começa na criação da KEY.",12f,0xFF9B9EAA.toInt()); root.addView(status)
        root.addView(button("ENTRAR") { val k=key.text.toString().trim(); if(!agree.isChecked){status.text="Marque a confirmação antes de continuar.";status.setTextColor(red)}else if(k.isBlank()){status.text="Digite sua KEY.";status.setTextColor(red)}else validateKey(k,status) },LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT).apply{topMargin=14})
        root.addView(text("SXZ • RED / BLACK • v1.0",11f,0xFF6F727E.toInt())); setContentView(root)
    }
    private fun validateKey(key:String,status:TextView){ status.text="Verificando licença..."; status.setTextColor(Color.LTGRAY)
        io.execute { try { val conn=URL("$API_BASE_URL/api/keys/validate").openConnection() as HttpURLConnection; conn.requestMethod="POST"; conn.connectTimeout=8000;conn.readTimeout=8000;conn.doOutput=true;conn.setRequestProperty("Content-Type","application/json");conn.outputStream.use{it.write(JSONObject().put("key",key).toString().toByteArray())};val stream=if(conn.responseCode in 200..299)conn.inputStream else conn.errorStream;val body=stream.bufferedReader().use{it.readText()};val obj=JSONObject(body);runOnUiThread { if(conn.responseCode in 200..299&&obj.optBoolean("valid")){status.text="Licença válida!";status.setTextColor(0xFF8DF0B0.toInt());enterMenu()}else{status.text=obj.optString("message","KEY inválida.");status.setTextColor(red)} };conn.disconnect() }catch(_:Exception){runOnUiThread{status.text="Não foi possível conectar ao servidor. Verifique a API.";status.setTextColor(red)}} }
    }
    private fun enterMenu(){ if(!Settings.canDrawOverlays(this)){startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); Toast.makeText(this,"Permita exibir sobre outros apps e toque ENTRAR novamente.",Toast.LENGTH_LONG).show(); return }; startService(Intent(this,FloatingMenuService::class.java)); Toast.makeText(this,"Menu flutuante ativado",Toast.LENGTH_SHORT).show(); finish() }
}
