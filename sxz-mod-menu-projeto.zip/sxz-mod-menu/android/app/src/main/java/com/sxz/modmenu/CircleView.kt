package com.sxz.modmenu

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

class CircleView(context: Context): View(context) {
    var diameter: Float=180f
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(255,35,63);style=Paint.Style.STROKE;strokeWidth=4f}
    override fun onDraw(canvas:Canvas){super.onDraw(canvas);val r=(diameter.coerceAtMost(width.toFloat()).coerceAtMost(height.toFloat())/2f)-paint.strokeWidth;canvas.drawCircle(width/2f,height/2f,r,paint)}
}
