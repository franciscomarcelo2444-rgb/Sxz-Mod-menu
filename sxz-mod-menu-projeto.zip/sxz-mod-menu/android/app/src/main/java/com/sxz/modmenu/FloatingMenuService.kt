package com.sxz.modmenu

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*

class FloatingMenuService : Service() {
    private lateinit var wm: WindowManager
    private var menu: LinearLayout?=null; private var circle: CircleView?=null; private var circleParams: WindowManager.LayoutParams?=null
    private val red=Color.rgb(255,35,63); private val black=Color.rgb(12,13,18); private val dark=Color.rgb(27,29,37)
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int { if(menu==null) showMenu(); return START_STICKY }
    private fun lp(w:Int,h:Int)=WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=30;y=120}
    private fun rounded(color:Int)=GradientDrawable().apply{setColor(color);cornerRadius=22f;setStroke(1,0xFF383A45.toInt())}
    private fun label(s:String,size:Float=14f)=TextView(this).apply{text=s;textSize=size;setTextColor(Color.WHITE);setPadding(12,8,12,8)}
    private fun btn(s:String,fn:()->Unit)=Button(this).apply{text=s;setTextColor(Color.WHITE);backgroundTintList=android.content.res.ColorStateList.valueOf(red);setOnClickListener{fn()}}
    private fun showMenu(){
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,10,12,12);background=rounded(black)}
        val header=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;orientation=LinearLayout.HORIZONTAL}
        val title=label("◉ SXZ MOD MENU",16f).apply{setTextColor(red);setTypeface(null,1)};header.addView(title,LinearLayout.LayoutParams(0,-2,1f));header.addView(btn("—"){ menu?.visibility=View.GONE; showBubble() });header.addView(btn("×"){stopSelf()});root.addView(header)
        root.addView(label("CÍRCULO VISUAL",12f).apply{setTextColor(0xFFB5B7C2.toInt())})
        val toggle=Switch(this).apply{text="Ativar círculo vermelho";setTextColor(Color.WHITE);buttonTintList=android.content.res.ColorStateList.valueOf(red);isChecked=false}
        root.addView(toggle)
        root.addView(label("Tamanho do círculo"));val slider=SeekBar(this).apply{max=450;progress=140;progressTintList=android.content.res.ColorStateList.valueOf(red);thumbTintList=android.content.res.ColorStateList.valueOf(red)};root.addView(slider)
        root.addView(label("O círculo é apenas visual e ajustável." ,11f).apply{setTextColor(0xFF999CAA.toInt())})
        toggle.setOnCheckedChangeListener{_,checked->if(checked)showCircle(slider.progress+50)else hideCircle()};slider.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){resizeCircle(p+50)};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){}})
        menu=root;wm.addView(root,lp(300,-2));makeDraggable(header,root)
    }
    private fun makeDraggable(handle:View,target:View){var sx=0;var sy=0;var wx=0;var wy=0;handle.setOnTouchListener{_,e->val p=target.layoutParams as WindowManager.LayoutParams;when(e.action){MotionEvent.ACTION_DOWN->{sx=e.rawX.toInt();sy=e.rawY.toInt();wx=p.x;wy=p.y;true};MotionEvent.ACTION_MOVE->{p.x=wx+e.rawX.toInt()-sx;p.y=wy+e.rawY.toInt()-sy;wm.updateViewLayout(target,p);true};else->false}}}
    private fun showCircle(d: Int){if(circle!=null){circle!!.diameter=d.toFloat();circle!!.invalidate();return};circle=CircleView(this).apply{diameter=d.toFloat()};circleParams=WindowManager.LayoutParams(d,d,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.CENTER};wm.addView(circle,circleParams)}
    private fun resizeCircle(d:Int){
        val c=circle ?: return
        c.diameter=d.toFloat()
        val params=circleParams ?: return
        params.width=d; params.height=d
        try { wm.updateViewLayout(c,params) } catch (_:Exception) {}
        c.invalidate()
    }
    private fun hideCircle(){circle?.let{try{wm.removeView(it)}catch(_:Exception){}};circle=null;circleParams=null}
    private fun showBubble(){if(menu?.parent!=null){try{wm.removeView(menu)}catch(_:Exception){}};val b=btn("SXZ"){menu?.visibility=View.VISIBLE};b.textSize=17f;b.background=rounded(red);wm.addView(b,lp(80,65));b.setOnTouchListener(object:View.OnTouchListener{var x=0;var y=0;var sx=0f;var sy=0f;override fun onTouch(v:View,e:MotionEvent):Boolean{val p=v.layoutParams as WindowManager.LayoutParams;when(e.action){MotionEvent.ACTION_DOWN->{x=p.x;y=p.y;sx=e.rawX;sy=e.rawY;return true};MotionEvent.ACTION_MOVE->{p.x=x+(e.rawX-sx).toInt();p.y=y+(e.rawY-sy).toInt();wm.updateViewLayout(v,p);return true};MotionEvent.ACTION_UP->{try{wm.removeView(v)}catch(_:Exception){};menu?.let{it.visibility=View.VISIBLE;if(it.parent==null)wm.addView(it,lp(300,-2))};return true}};return false}})}
    override fun onDestroy(){hideCircle();menu?.let{try{wm.removeView(it)}catch(_:Exception){}};menu=null;super.onDestroy()}
}
